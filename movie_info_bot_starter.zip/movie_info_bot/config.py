import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    API_ID: int = int(os.getenv("API_ID", "0"))
    API_HASH: str = os.getenv("API_HASH", "")
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
    TMDB_API_TOKEN: str = os.getenv("TMDB_API_TOKEN", "")
    WATCHMODE_API_KEY: str = os.getenv("WATCHMODE_API_KEY", "")
    WATCHMODE_REGION: str = os.getenv("WATCHMODE_REGION", "IN")


settings = Settings()

required = {
    "API_ID": settings.API_ID,
    "API_HASH": settings.API_HASH,
    "BOT_TOKEN": settings.BOT_TOKEN,
    "TMDB_API_TOKEN": settings.TMDB_API_TOKEN,
    "WATCHMODE_API_KEY": settings.WATCHMODE_API_KEY,
}
missing = [name for name, value in required.items() if not value]
if missing:
    raise RuntimeError("Missing environment variables: " + ", ".join(missing))
