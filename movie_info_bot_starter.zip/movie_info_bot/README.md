# Movie Info Bot

A private-chat-only Telegram bot that combines:

- **TMDB** for movie title, poster, genres, release year/date, rating, spoken languages, runtime, director and cast.
- **Watchmode** for streaming availability in the configured country.

## Commands

- `/start`
- `/info Movie Name`
- Or simply send a movie title in the private chat.

The bot intentionally does not process group messages.

## Requirements

- Python 3.10+
- Telegram bot token from BotFather
- Telegram API ID and API hash from https://my.telegram.org
- TMDB API Read Access Token from https://www.themoviedb.org/settings/api
- Watchmode API key from https://api.watchmode.com/

## Run locally

1. Create a virtual environment.
2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Copy `.env.example` to `.env`.
4. Fill in the environment variables. Never commit `.env`.
5. Start:

   ```bash
   python bot.py
   ```

## Render deployment

Create a **Background Worker** from this repository. Render can use the included `render.yaml`.
Add the environment variables from `.env.example` in the Render dashboard. Do not put API keys in source code.

## How the two APIs are combined

TMDB is the primary metadata source. The bot searches TMDB, retrieves details and credits, then maps the TMDB movie ID through Watchmode's search endpoint and requests streaming sources for the configured region.

If Watchmode has no match or no sources for a title, the bot still returns the TMDB movie information.

## Important notes

- The Watchmode Developer plan has a monthly credit limit and country restrictions; check your account plan and usage.
- Watchmode's free Developer plan requires attribution and is for non-commercial use. Keep the attribution line in the bot response.
- This bot provides metadata and official availability information only. It does not download or stream movies.
- Include the TMDB notice in the bot: “This product uses the TMDB API but is not endorsed or certified by TMDB.” Review TMDB's current API terms and attribution requirements before public release.
- Pyrogram's original project is no longer maintained. This project uses Pyrofork, a maintained-compatible fork.
- Search results can be ambiguous. Include the release year in the search phrase when necessary.
