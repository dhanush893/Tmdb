import asyncio
import logging
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import FloodWait
from config import settings
from movie_api import MovieService

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
log = logging.getLogger("movie-info-bot")

app = Client(
    name="movie_info_bot",
    api_id=settings.API_ID,
    api_hash=settings.API_HASH,
    bot_token=settings.BOT_TOKEN,
)
movies = MovieService()


def format_movie(data: dict) -> str:
    def val(key, fallback="Not available"):
        value = data.get(key)
        return str(value) if value not in (None, "", [], {}) else fallback

    rating = data.get("rating")
    rating_text = f"{rating:.1f} / 10" if isinstance(rating, (int, float)) else "Not available"

    genres = ", ".join(data.get("genres") or []) or "Not available"
    languages = ", ".join(data.get("languages") or []) or "Not available"
    runtime = data.get("runtime")
    runtime_text = f"{runtime} Minutes" if runtime else "Not available"

    lines = [
        f"📝 ᴛɪᴛʟᴇ - {val('title')}",
        f"🎭 ɢᴇɴʀᴇs - {genres}",
        f"📆 ʏᴇᴀʀ - {val('year')}",
        f"〽️ ʀᴀᴛɪɴɢ - {rating_text}",
        f"🔉 ʟᴀɴɢᴜᴀɢᴇ - {languages}",
        f"🔂 ʀᴜɴ ᴛɪᴍᴇ - {runtime_text}",
        "",
        f"🎬 ᴅɪʀᴇᴄᴛᴏʀ - {val('director')}",
        f"🌟 ᴄᴀsᴛ - {val('cast')}",
        f"📅 ʀᴇʟᴇᴀsᴇ - {val('release_date')}",
    ]

    providers = data.get("providers") or []
    if providers:
        lines += ["", "📺 ᴀᴠᴀɪʟᴀʙʟᴇ ᴏɴ"]
        for provider in providers[:8]:
            name = provider.get("name", "Streaming service")
            kind = provider.get("type", "")
            url = provider.get("url")
            lines.append(f"• {name}" + (f" — {kind}" if kind else "") + (f"\n{url}" if url else ""))

    lines += ["", "ℹ️ Metadata: TMDB • Streaming availability: Watchmode"]
    return "\n".join(lines)


async def send_movie(client, message, query: str):
    query = query.strip()
    if not query:
        await message.reply_text("Send a movie title after /info.\nExample: /info Interstellar")
        return

    status = await message.reply_text("🔎 Searching TMDB and Watchmode...")
    try:
        result = await movies.get_movie(query, country=settings.WATCHMODE_REGION)
        if not result:
            await status.edit_text("❌ No matching movie found. Try the original title or add the release year.")
            return

        caption = format_movie(result)
        poster = result.get("poster")
        keyboard = None
        if result.get("tmdb_url"):
            keyboard = InlineKeyboardMarkup(
                [[InlineKeyboardButton("TMDB details", url=result["tmdb_url"])]]
            )

        if poster:
            await status.delete()
            await client.send_photo(
                chat_id=message.chat.id,
                photo=poster,
                caption=caption[:1024],
                reply_markup=keyboard,
            )
            if len(caption) > 1024:
                await message.reply_text(caption[1024:], disable_web_page_preview=True)
        else:
            await status.edit_text(caption, reply_markup=keyboard, disable_web_page_preview=True)

    except FloodWait as exc:
        await asyncio.sleep(exc.value)
        await message.reply_text("Please try your search again.")
    except Exception:
        log.exception("Movie lookup failed")
        await status.edit_text("⚠️ I couldn't complete that search. Check the API setup and try again.")


@app.on_message(filters.private & filters.command("start"))
async def start(_, message):
    await message.reply_text(
        "🎬 **Welcome to Movie Info Bot!**\n\n"
        "Send a movie title, or use:\n"
        "`/info Movie Name`\n\n"
        "I’ll show the poster, genres, year, rating, languages, runtime, "
        "director, cast, release date and available streaming services.\n\n"
        "🔒 This bot responds in private chats only."
    )


@app.on_message(filters.private & filters.command("info"))
async def info_command(client, message):
    query = " ".join(message.command[1:]) if len(message.command) > 1 else ""
    await send_movie(client, message, query)


@app.on_message(filters.private & filters.text & ~filters.command(["start", "info"]))
async def plain_text_search(client, message):
    await send_movie(client, message, message.text)


@app.on_message(~filters.private)
async def reject_groups(_, message):
    # No group response; the bot is private-chat-only.
    return


if __name__ == "__main__":
    log.info("Starting private-chat-only Movie Info Bot")
    app.run()
