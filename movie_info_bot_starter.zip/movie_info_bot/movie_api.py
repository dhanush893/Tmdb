import asyncio
import logging
from typing import Optional
import httpx
from config import settings

log = logging.getLogger(__name__)

TMDB_BASE = "https://api.themoviedb.org/3"
WATCHMODE_BASE = "https://api.watchmode.com/v1"


class MovieService:
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=20.0)

    async def _tmdb(self, path: str, params: dict | None = None):
        response = await self.client.get(
            f"{TMDB_BASE}{path}",
            params=params or {},
            headers={"Authorization": f"Bearer {settings.TMDB_API_TOKEN}"},
        )
        response.raise_for_status()
        return response.json()

    async def _watchmode(self, path: str, params: dict | None = None):
        response = await self.client.get(
            f"{WATCHMODE_BASE}{path}",
            params=params or {},
            headers={"X-API-Key": settings.WATCHMODE_API_KEY},
        )
        response.raise_for_status()
        return response.json()

    async def get_movie(self, query: str, country: str = "IN") -> Optional[dict]:
        # TMDB is the primary source for title metadata and poster.
        search = await self._tmdb("/search/movie", {"query": query, "include_adult": "false"})
        results = search.get("results") or []
        if not results:
            return None

        # Prefer the first relevant result. Users can add a year to narrow ambiguous titles.
        selected = results[0]
        movie_id = selected["id"]
        details = await self._tmdb(
            f"/movie/{movie_id}",
            {"append_to_response": "credits,release_dates"},
        )

        genres = [item["name"] for item in details.get("genres", [])]
        languages = [
            item.get("english_name") or item.get("name")
            for item in details.get("spoken_languages", [])
            if item.get("english_name") or item.get("name")
        ]
        crew = (details.get("credits") or {}).get("crew") or []
        directors = [p["name"] for p in crew if p.get("job") == "Director"]
        cast = [
            p["name"] for p in ((details.get("credits") or {}).get("cast") or [])[:8]
            if p.get("name")
        ]

        # TMDB rating is already on a 10-point scale.
        rating = details.get("vote_average")
        release_date = details.get("release_date") or "Not available"

        # Watchmode adds streaming sources. Use TMDB id mapping to avoid fuzzy title mismatches.
        watchmode_id = None
        providers = []
        try:
            mapped = await self._watchmode("/search/", {
                "search_field": "tmdb_movie_id",
                "search_value": str(movie_id),
            })
            matches = mapped.get("title_results") or []
            if matches:
                watchmode_id = matches[0].get("id")
        except (httpx.HTTPError, ValueError) as exc:
            log.warning("Watchmode ID lookup failed: %s", exc)

        if watchmode_id:
            try:
                sources = await self._watchmode(f"/title/{watchmode_id}/sources/", {
                    "regions": country,
                })
                for source in sources if isinstance(sources, list) else []:
                    providers.append({
                        "name": source.get("name") or source.get("source_name") or "Streaming service",
                        "type": source.get("type") or source.get("format") or "",
                        "url": source.get("web_url") or source.get("link"),
                    })
            except (httpx.HTTPError, ValueError) as exc:
                log.warning("Watchmode sources lookup failed: %s", exc)

        year = release_date[:4] if release_date and len(release_date) >= 4 else None
        return {
            "title": details.get("title") or selected.get("title"),
            "genres": genres,
            "year": year,
            "rating": rating,
            "languages": languages,
            "runtime": details.get("runtime"),
            "director": ", ".join(directors) or None,
            "cast": ", ".join(cast) or None,
            "release_date": release_date,
            "poster": (
                f"https://image.tmdb.org/t/p/w500{details['poster_path']}"
                if details.get("poster_path") else None
            ),
            "tmdb_url": f"https://www.themoviedb.org/movie/{movie_id}",
            "providers": providers,
        }

    async def close(self):
        await self.client.aclose()
